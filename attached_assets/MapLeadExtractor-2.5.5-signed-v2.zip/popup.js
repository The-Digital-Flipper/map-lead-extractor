import { Commands, ROUTE_TO_CONTENT } from "./src/messages.js";

const SITE_URL = "https://mapleadextractor.net";
const API_KEY_STORAGE = "mapLeadExtractor.apiKey";
const EMAIL_STORAGE = "mapLeadExtractor.userEmail";

const signedOut = document.getElementById("signedOut");
const signedIn = document.getElementById("signedIn");
const userEmailEl = document.getElementById("userEmail");
const statusMsg = document.getElementById("statusMsg");

async function sendToContent(command, payload = {}) {
  return chrome.runtime.sendMessage({
    type: ROUTE_TO_CONTENT,
    payload: { command, ...payload }
  });
}

async function loadState() {
  const stored = await chrome.storage.local.get([API_KEY_STORAGE, EMAIL_STORAGE]);
  const email = stored[EMAIL_STORAGE] || "";
  const apiKey = stored[API_KEY_STORAGE] || "";
  if (email && apiKey) {
    showSignedIn(email);
  } else {
    showSignedOut();
  }
}

function showSignedIn(email) {
  signedOut.hidden = true;
  signedIn.hidden = false;
  userEmailEl.textContent = email;
}

function showSignedOut() {
  signedIn.hidden = true;
  signedOut.hidden = false;
}

// Sign in → open connect page on the site
document.getElementById("signInBtn").addEventListener("click", async () => {
  await chrome.tabs.create({ url: `${SITE_URL}/connect-extension` });
  window.close();
});

// Open Bing Maps (signed-out state)
document.getElementById("openBingOut").addEventListener("click", async () => {
  await chrome.tabs.create({ url: "https://www.bing.com/maps" });
  window.close();
});

// Open extractor panel (signed-in state)
document.getElementById("openPanelBtn").addEventListener("click", async () => {
  statusMsg.textContent = "Opening extractor...";
  const response = await sendToContent(Commands.SHOW_PANEL);
  if (response?.ok) {
    window.close();
    return;
  }
  statusMsg.textContent = response?.error || "Open Bing Maps first, then try again.";
});

// Open Bing Maps (signed-in state)
document.getElementById("openBingIn").addEventListener("click", async () => {
  await chrome.tabs.create({ url: "https://www.bing.com/maps" });
  window.close();
});

// Disconnect / sign out
document.getElementById("disconnectBtn").addEventListener("click", async () => {
  await chrome.storage.local.remove([API_KEY_STORAGE, EMAIL_STORAGE]);
  showSignedOut();
  statusMsg.textContent = "Signed out.";
});

loadState();
