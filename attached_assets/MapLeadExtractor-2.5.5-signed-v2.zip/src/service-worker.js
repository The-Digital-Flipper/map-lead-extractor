import { Commands, ROUTE_TO_CONTENT } from "./messages.js";
import { EXTENSION_VERSION } from "./version.js";

const LOCAL_ID_KEY = "mapLeadExtractor.localId";
const API_KEY_STORAGE = "mapLeadExtractor.apiKey";
const EMAIL_STORAGE = "mapLeadExtractor.userEmail";

chrome.runtime.onInstalled.addListener(async ({ reason }) => {
  const existing = await chrome.storage.local.get(LOCAL_ID_KEY);
  if (!existing[LOCAL_ID_KEY]) {
    await chrome.storage.local.set({ [LOCAL_ID_KEY]: crypto.randomUUID() });
  }
  if (reason === "install") {
    await chrome.storage.local.set({ "mapLeadExtractor.panelOpen": true });
    chrome.tabs.create({ url: "https://www.bing.com/maps?q=food%20in%20Dallas" });
  }
});

async function getActiveBingMapsTab() {
  const tabs = await chrome.tabs.query({
    active: true,
    currentWindow: true,
    url: "*://*.bing.com/maps*"
  });
  return tabs[0] || null;
}

async function routeToContent(message, sender) {
  const tabId = sender.tab?.id || (await getActiveBingMapsTab())?.id;
  if (!tabId) {
    return {
      ok: false,
      error: "Open Bing Maps before starting extraction."
    };
  }

  try {
    return await chrome.tabs.sendMessage(tabId, message.payload || {});
  } catch (error) {
    return {
      ok: false,
      error: "Bing Maps content script is not ready. Refresh the Bing Maps tab and try again.",
      detail: error?.message || String(error)
    };
  }
}

const MAX_SITE_CHARS = 400000;
async function fetchSite(url, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      credentials: "omit",
      redirect: "follow",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
      }
    });
    if (!response.ok) return { ok: false, text: "", status: response.status, error: `http ${response.status}` };
    const type = response.headers.get("content-type") || "";
    if (type && !/text\/html|text\/plain|application\/xhtml/i.test(type)) {
      return { ok: false, text: "", status: response.status, error: `non-html (${type.split(";")[0]})` };
    }
    const text = await response.text();
    return { ok: true, text: text.length > MAX_SITE_CHARS ? text.slice(0, MAX_SITE_CHARS) : text, status: response.status, error: "" };
  } catch (e) {
    const msg = (e && e.name === "AbortError") ? "timeout" : ((e && e.message) || "fetch failed");
    return { ok: false, text: "", status: 0, error: msg };
  } finally {
    clearTimeout(timer);
  }
}

// Internal messages (from popup / panel)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === ROUTE_TO_CONTENT) {
      sendResponse(await routeToContent(message, sender));
      return;
    }

    if (message?.command === Commands.GET_STATUS) {
      sendResponse({ ok: true, version: EXTENSION_VERSION });
      return;
    }

    if (message?.command === Commands.FETCH_SITE) {
      sendResponse(await fetchSite(message.url, message.timeoutMs || 9000));
      return;
    }

    sendResponse({ ok: false, error: "Unknown service worker message." });
  })();

  return true;
});

// External messages from mapleadextractor.net (via externally_connectable)
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  (async () => {
    // Site pushes API key + email after Google sign-in
    if (message?.type === "MLE_CONNECT") {
      await chrome.storage.local.set({
        [API_KEY_STORAGE]: message.apiKey || "",
        [EMAIL_STORAGE]: message.email || ""
      });
      sendResponse({ ok: true });
      return;
    }

    // Site checks whether extension is installed and connected
    if (message?.type === "MLE_GET_STATUS") {
      const stored = await chrome.storage.local.get([API_KEY_STORAGE, EMAIL_STORAGE]);
      sendResponse({
        ok: true,
        connected: !!(stored[API_KEY_STORAGE] && stored[EMAIL_STORAGE]),
        email: stored[EMAIL_STORAGE] || ""
      });
      return;
    }

    // Site requests sign-out
    if (message?.type === "MLE_DISCONNECT") {
      await chrome.storage.local.remove([API_KEY_STORAGE, EMAIL_STORAGE]);
      sendResponse({ ok: true });
      return;
    }

    sendResponse({ ok: false, error: "Unknown external message type." });
  })();

  return true;
});
