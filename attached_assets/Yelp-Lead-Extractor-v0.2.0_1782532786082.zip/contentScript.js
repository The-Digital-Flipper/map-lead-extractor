/* Yelp Lead Extractor — Command Center
 * --------------------------------------------------------------------------
 * Same look & feature set as the Map Lead Extractor "Command Center", adapted
 * to Yelp search pages: mode dropdown, Start/Stop, Auto Scroll (auto-paging),
 * live-leads feed, LeadScore, Preview modal, multi-sheet export, dedupe,
 * delete-weak, check-missing, sessions, draggable/hideable panel.
 *
 * Educational / personal use. Go slow, respect Yelp's Terms of Service.
 * -------------------------------------------------------------------------- */

(function () {
  "use strict";
  if (window.__yleLoaded) return;
  window.__yleLoaded = true;

  const VERSION = "v0.2 · YELP";

  const state = {
    running: false,
    leads: [],
    seen: new Set(),
    mode: "all",          // all | phones | social | fast | manual
    autoScroll: true,
    enrichDetail: true,   // fetch each business page for phone/website
    collectEmail: true,   // fetch business website for email/socials
  };

  // ---------- tiny helpers ----------
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const rand = (min, max) => Math.floor(Math.random() * (max - min) + min);
  const norm = (s) => (s ? String(s).replace(/\s+/g, " ").trim() : "");
  const $ = (sel) => document.querySelector(sel);
  const escapeHtml = (s) => String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const escapeAttr = (s) => escapeHtml(s).replace(/"/g, "&quot;");

  function status(text) { const el = $("#yle-status"); if (el) el.textContent = text; }

  // ---------- lead scoring (mirrors LeadScore / QualityTier) ----------
  function scoreLead(l) {
    let s = 0;
    if (l.phone) s += 40;
    if (l.email) s += 30;
    if (l.website) s += 20;
    if (l.rating) s += 10;
    return s;
  }
  function tier(score) { return score >= 70 ? "Strong" : score >= 30 ? "Partial" : "Weak"; }

  // ---------- persistence (survives the reload between pages) ----------
  async function loadState() {
    const s = await chrome.storage.local.get(["yle_leads", "yle_seen", "yle_running", "yle_mode", "yle_auto"]);
    state.leads = s.yle_leads || [];
    state.seen = new Set(s.yle_seen || []);
    state.running = !!s.yle_running;
    state.mode = s.yle_mode || "all";
    state.autoScroll = s.yle_auto !== false;
    applyMode(state.mode);
  }
  async function saveState() {
    await chrome.storage.local.set({
      yle_leads: state.leads, yle_seen: [...state.seen],
      yle_running: state.running, yle_mode: state.mode, yle_auto: state.autoScroll,
    });
  }
  async function clearLeads() {
    state.leads = []; state.seen = new Set(); state.running = false;
    await saveState(); refreshAll(); status("Cleared all leads.");
  }

  // ---------- reading Yelp's embedded data (the heart) ----------
  function parseJsonSafely(t) { try { return JSON.parse(t); } catch (e) { return null; } }

  function extractBalancedObject(str, from) {
    const start = str.indexOf("{", from);
    if (start === -1) return "";
    let depth = 0, inStr = false, quote = "", esc = false;
    for (let i = start; i < str.length; i++) {
      const c = str[i];
      if (inStr) { if (esc) esc = false; else if (c === "\\") esc = true; else if (c === quote) inStr = false; }
      else if (c === '"' || c === "'") { inStr = true; quote = c; }
      else if (c === "{") depth++;
      else if (c === "}") { depth--; if (depth === 0) return str.slice(start, i + 1); }
    }
    return "";
  }

  function getApolloStates(doc) {
    const states = [];
    doc.querySelectorAll("script[data-apollo-state]").forEach((s) => {
      const obj = parseJsonSafely(s.textContent.trim().replace(/^<!--|-->$/g, ""));
      if (obj) states.push(obj);
    });
    doc.querySelectorAll("script").forEach((s) => {
      const t = s.textContent || "";
      const idx = t.indexOf("window.yelp.react_apollo_state");
      if (idx === -1) return;
      const eq = t.indexOf("=", idx + 30);
      if (eq === -1) return;
      const obj = parseJsonSafely(extractBalancedObject(t, eq + 1));
      if (obj) states.push(obj);
    });
    return states;
  }

  function fmtAddress(f) {
    if (!f) return "";
    if (Array.isArray(f)) return f.map(norm).filter(Boolean).join(", ");
    return String(f).split("\n").map(norm).filter(Boolean).join(", ");
  }
  function extractCategories(node) {
    const c = node.categories;
    if (!Array.isArray(c)) return "";
    return c.map((x) => norm(x && (x.title || x.name))).filter(Boolean).join(", ");
  }

  // (1) JSON-LD — the reliable structured-data block on every Yelp business page.
  function parseJsonLd(doc, out) {
    doc.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
      let data; try { data = JSON.parse(s.textContent); } catch (e) { return; }
      const nodes = Array.isArray(data) ? data : (data["@graph"] || [data]);
      nodes.forEach((n) => {
        if (!n || typeof n !== "object") return;
        if (n.telephone && !out.phone) out.phone = norm(n.telephone);
        if (n.address && !out.address && typeof n.address === "object") {
          const a = n.address;
          out.address = norm([a.streetAddress, a.addressLocality, a.addressRegion, a.postalCode]
            .filter(Boolean).join(", "));
        }
        if (n.aggregateRating) {
          out.rating = out.rating || (n.aggregateRating.ratingValue ?? "");
          out.reviewCount = out.reviewCount || (n.aggregateRating.reviewCount ?? n.aggregateRating.ratingCount ?? "");
        }
        if (n.priceRange && !out.priceRange) out.priceRange = norm(n.priceRange);
        if (n.servesCuisine && !out.categories) out.categories = [].concat(n.servesCuisine).join(", ");
        if (n.geo && !out.latitude) { out.latitude = n.geo.latitude ?? ""; out.longitude = n.geo.longitude ?? ""; }
      });
    });
  }

  // (2) Website — Yelp links out through /biz_redir?url=<encoded real site>.
  function decodeBizRedir(href) {
    const m = (href || "").match(/[?&]url=([^&]+)/);
    try { return m ? decodeURIComponent(m[1]) : ""; } catch (e) { return ""; }
  }
  function extractWebsite(doc) {
    let best = "";
    doc.querySelectorAll('a[href*="biz_redir"]').forEach((a) => {
      if (best) return;
      const href = a.getAttribute("href") || "";
      const url = decodeBizRedir(href);
      if (url && !/yelp\.com/i.test(url)) best = url;
    });
    return best;
  }

  function extractContact(doc) {
    const out = { phone: "", address: "", website: "", rating: "", reviewCount: "",
      categories: "", priceRange: "", latitude: "", longitude: "" };

    parseJsonLd(doc, out);                 // primary: phone, address, rating, reviews
    out.website = out.website || extractWebsite(doc);   // primary: website

    // (3) Apollo fallback — fills anything JSON-LD missed.
    for (const apollo of getApolloStates(doc)) {
      for (const key in apollo) {
        const node = apollo[key];
        if (!node || typeof node !== "object") continue;
        if (node.__typename === "Business") {
          out.phone = out.phone || norm(node.phoneNumber?.formatted || node.meteredPhoneNumber?.phoneText);
          out.website = out.website || norm(node.externalResources?.website?.url || node.externalResources?.website?.displayUrl);
          out.rating = out.rating || (node.rating ?? node.aggregateRating?.rating ?? "");
          out.reviewCount = out.reviewCount || (node.reviewCount ?? node.aggregateRating?.reviewCount ?? "");
          out.priceRange = out.priceRange || norm(node.priceRange || node.price);
          out.categories = out.categories || extractCategories(node);
        }
        if (node.__typename === "BusinessPhoneNumber") out.phone = out.phone || norm(node.formatted);
        if (node.__typename === "BusinessLocation") {
          if (node.address) out.address = out.address || fmtAddress(node.address.formatted);
          const co = node.coordinate || node.geoCoordinate || node.mapState?.coordinate;
          if (co) { out.latitude = out.latitude || (co.latitude ?? ""); out.longitude = out.longitude || (co.longitude ?? ""); }
        }
      }
    }

    // (4) DOM / regex fallbacks from the rendered page (phone, rating, reviews, price).
    const text = doc.body ? doc.body.textContent : "";
    if (!out.phone) {
      const m = text.match(/\(\d{3}\)\s*\d{3}[-.\s]?\d{4}/);
      if (m) out.phone = m[0];
    }
    if (!out.rating) {
      const star = doc.querySelector('[aria-label*="star rating" i]');
      if (star) out.rating = firstNum(star.getAttribute("aria-label"));
      else { const m = text.match(/([\d.]+)\s*star rating/i); if (m) out.rating = m[1]; }
    }
    if (!out.reviewCount) {
      const m = text.match(/([\d,]+)\s+reviews?\b/i);
      if (m) out.reviewCount = m[1].replace(/,/g, "");
    }
    if (!out.priceRange) {
      const m = text.match(/(?:^|[\s·•>])(\${1,4})(?=[\s·•<]|$)/);
      if (m) out.priceRange = m[1];
    }
    return out;
  }

  // ---------- email + social enrichment ----------
  const EMAIL_RE = /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi;
  const SOCIAL_RES = [
    /https?:\/\/(?:www\.)?facebook\.com\/[A-Za-z0-9_.\-]+/gi,
    /https?:\/\/(?:www\.)?instagram\.com\/[A-Za-z0-9_.\-]+/gi,
    /https?:\/\/(?:www\.)?linkedin\.com\/(?:company|in)\/[A-Za-z0-9_.\-]+/gi,
  ];
  const EMAIL_JUNK = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
    "noreply", "no-reply", "sentry", "wixpress", "example.com", "domain.com"];

  function decodeCfEmail(hex) {
    const key = parseInt(hex.substr(0, 2), 16); let out = "";
    for (let j = 2; j < hex.length; j += 2) out += String.fromCharCode(parseInt(hex.substr(j, 2), 16) ^ key);
    return out;
  }

  async function extractEmails(websiteUrl) {
    let url = websiteUrl;
    if (url.startsWith("//")) url = "https:" + url;
    if (!/^https?:/i.test(url)) url = "https://" + url;
    const res = await chrome.runtime.sendMessage({ action: "fetchUrl", url });
    if (!res || !res.ok || !res.text) return { emails: [], socials: [] };
    const html = res.text;
    const emails = new Set();
    (html.match(EMAIL_RE) || []).forEach((raw) => {
      const e = raw.toLowerCase();
      if (!EMAIL_JUNK.some((j) => e.includes(j))) emails.add(e);
    });
    try {
      const doc = new DOMParser().parseFromString(html, "text/html");
      doc.querySelectorAll(".__cf_email__").forEach((el) => {
        const d = el.getAttribute("data-cfemail"); if (d) emails.add(decodeCfEmail(d));
      });
    } catch (e) { /* ignore */ }
    const socials = new Set();
    SOCIAL_RES.forEach((re) => (html.match(re) || []).forEach((s) => socials.add(s)));
    return { emails: [...emails], socials: [...socials] };
  }

  // ---------- search page parsing ----------
  const firstNum = (s) => { const m = String(s || "").replace(/,/g, "").match(/[\d.]+/); return m ? m[0] : ""; };

  // Walk up from a business link to its result "card" (the box that holds the stars).
  function cardOf(anchor) {
    let el = anchor;
    for (let i = 0; i < 7 && el; i++) {
      el = el.parentElement;
      if (el && el.querySelector('[aria-label*="star rating" i]')) return el;
    }
    return anchor.closest("li") || anchor.parentElement;
  }

  // Pull rating / reviews / price straight from the rendered search card (no fetch).
  function parseCard(card) {
    const out = { rating: "", reviewCount: "", priceRange: "", categories: "" };
    if (!card) return out;
    const star = card.querySelector('[aria-label*="star rating" i]');
    if (star) out.rating = firstNum(star.getAttribute("aria-label"));
    const txt = card.textContent || "";
    let rc = txt.match(/(\d[\d,]*)\s*reviews?/i) || txt.match(/\((\d[\d,]*)\)/);
    if (rc) out.reviewCount = rc[1].replace(/,/g, "");
    const price = txt.match(/\${1,4}(?=[\s·•]|$)/);
    if (price) out.priceRange = price[0];
    return out;
  }

  function collectBusinessLinks() {
    const out = []; const seenPath = new Set();
    document.querySelectorAll('a[href*="/biz/"]').forEach((a) => {
      const name = norm(a.textContent);
      if (!name || name.length < 2) return;
      let path; try { path = new URL(a.getAttribute("href"), location.origin).pathname; } catch (e) { return; }
      if (!/^\/biz\//.test(path) || seenPath.has(path)) return;
      seenPath.add(path);
      const card = parseCard(cardOf(a));
      out.push({ name, url: location.origin + path, ...card });
    });
    return out;
  }
  function findNextPageLink() {
    return document.querySelector('a[aria-label="Next"], a.next-link, a[href*="start="][class*="next" i]');
  }
  async function fetchYelpDoc(url) {
    const res = await fetch(url, { credentials: "include" });
    return new DOMParser().parseFromString(await res.text(), "text/html");
  }

  // ---------- the scrape loop ----------
  function makeLead(biz) {
    return { name: biz.name, url: biz.url, phone: "", address: "", website: "", email: "", socials: "",
      rating: biz.rating || "", reviewCount: biz.reviewCount || "",
      categories: biz.categories || "", priceRange: biz.priceRange || "",
      latitude: "", longitude: "", LeadScore: 0, QualityTier: "Weak" };
  }

  async function enrichLead(lead) {
    if (state.enrichDetail) {
      const doc = await fetchYelpDoc(lead.url);
      const c = extractContact(doc);
      // Only FILL gaps — never overwrite the reliable values already read from the search card.
      lead.phone = lead.phone || c.phone;
      lead.website = lead.website || c.website;
      lead.address = lead.address || c.address;
      lead.rating = lead.rating || c.rating;
      lead.reviewCount = lead.reviewCount || c.reviewCount;
      lead.categories = lead.categories || c.categories;
      lead.priceRange = lead.priceRange || c.priceRange;
      lead.latitude = lead.latitude || c.latitude;
      lead.longitude = lead.longitude || c.longitude;
    }
    if (state.collectEmail && lead.website) {
      const { emails, socials } = await extractEmails(lead.website);
      lead.email = emails.join("; ");
      lead.socials = socials.join("; ");
    }
    lead.LeadScore = scoreLead(lead);
    lead.QualityTier = tier(lead.LeadScore);
  }

  async function processCurrentPage() {
    const businesses = collectBusinessLinks();
    status(`Found ${businesses.length} businesses on this page.`);
    for (const biz of businesses) {
      if (!state.running) return;
      if (state.seen.has(biz.url)) continue;
      state.seen.add(biz.url);
      const lead = makeLead(biz);
      try {
        status(`${state.enrichDetail ? "Reading" : "Saving"}: ${biz.name}`);
        await enrichLead(lead);
      } catch (e) { console.warn("[YLE] lead error", biz.url, e); }
      state.leads.push(lead);
      await saveState(); refreshAll();
      await sleep(state.enrichDetail ? rand(1500, 3500) : rand(300, 800));
    }
    if (!state.running) return;
    if (!state.autoScroll) { finish("Manual page done."); return; }
    const next = findNextPageLink();
    if (next) {
      status("Going to next page...");
      await saveState();
      await sleep(rand(1200, 2500));
      next.click();   // navigates -> script reloads and resumes
    } else {
      finish(`Done — ${state.leads.length} leads collected.`);
    }
  }

  // enrich already-collected leads (modes: phones / social)
  async function enrichExisting(kind) {
    const targets = state.leads.filter((l) =>
      kind === "phones" ? (!l.phone || !l.website) : (!l.email));
    if (!targets.length) { finish("Nothing missing to enrich."); return; }
    let done = 0;
    for (const lead of targets) {
      if (!state.running) break;
      try {
        status(`${kind === "phones" ? "Phone/site" : "Email"} for: ${lead.name} (${++done}/${targets.length})`);
        if (kind === "phones") {
          const c = extractContact(await fetchYelpDoc(lead.url));
          lead.phone = lead.phone || c.phone;
          lead.website = lead.website || c.website;
        } else if (lead.website) {
          const { emails, socials } = await extractEmails(lead.website);
          lead.email = lead.email || emails.join("; ");
          lead.socials = lead.socials || socials.join("; ");
        }
        lead.LeadScore = scoreLead(lead); lead.QualityTier = tier(lead.LeadScore);
      } catch (e) { console.warn("[YLE] enrich error", e); }
      await saveState(); refreshAll();
      await sleep(rand(1200, 3000));
    }
    finish(`Enriched ${done} leads.`);
  }

  function applyMode(mode) {
    state.mode = mode;
    if (mode === "all")    { state.enrichDetail = true;  state.collectEmail = true;  state.autoScroll = true; }
    if (mode === "fast")   { state.enrichDetail = false; state.collectEmail = false; state.autoScroll = true; }
    if (mode === "manual") { state.enrichDetail = true;  state.collectEmail = true;  state.autoScroll = false; }
    if (mode === "phones") { state.enrichDetail = true;  state.collectEmail = false; }
    if (mode === "social") { state.enrichDetail = false; state.collectEmail = true; }
  }

  async function start() {
    if (state.running) return;
    state.running = true;
    applyMode($("#yle-mode") ? $("#yle-mode").value : state.mode);
    await saveState(); setRunning(true);
    if (state.mode === "phones" || state.mode === "social") enrichExisting(state.mode);
    else processCurrentPage();
  }
  async function stop() { state.running = false; await saveState(); setRunning(false); status("Stopped."); }
  async function finish(msg) { state.running = false; await saveState(); setRunning(false); status(msg); }

  // ---------- data tools ----------
  async function cleanDuplicates() {
    const seen = new Set(); const out = [];
    for (const l of state.leads) {
      const key = (l.name + "|" + (l.address || l.url)).toLowerCase();
      if (seen.has(key)) continue; seen.add(key); out.push(l);
    }
    const removed = state.leads.length - out.length;
    state.leads = out; await saveState(); refreshAll();
    status(`Dedupe complete — removed ${removed} duplicates.`);
  }
  async function deleteWeak() {
    const before = state.leads.length;
    state.leads = state.leads.filter((l) => scoreLead(l) >= 30);
    await saveState(); refreshAll();
    status(`Deleted ${before - state.leads.length} weak leads.`);
  }
  function checkMissing() {
    const noPhone = state.leads.filter((l) => !l.phone).length;
    const noEmail = state.leads.filter((l) => !l.email).length;
    const noWeb = state.leads.filter((l) => !l.website).length;
    status(`Missing — phone: ${noPhone}, email: ${noEmail}, website: ${noWeb}.`);
  }

  // Diagnostic: fetch the FIRST business on this search page and report what we got.
  async function testFirst() {
    const list = collectBusinessLinks();
    if (!list.length) { status("⚠ No businesses found — are you on a Yelp SEARCH page?"); return; }
    const biz = list[0];
    status(`Testing: ${biz.name}…`);
    try {
      const res = await fetch(biz.url, { credentials: "include" });
      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, "text/html");
      const c = extractContact(doc);
      const ld = doc.querySelectorAll('script[type="application/ld+json"]').length;
      console.log("[YLE TEST] url:", biz.url, "| html chars:", html.length, "| page title:", doc.title, "| ld blocks:", ld, "| extracted:", c);
      status(`${html.length} chars · ld:${ld} · 📞${c.phone || "—"} · 🌐${c.website ? "yes" : "—"} · ★${c.rating || "—"} (${c.reviewCount || 0})`);
    } catch (e) {
      status("⚠ Fetch failed: " + e.message);
      console.warn("[YLE TEST] fetch error", e);
    }
  }
  async function saveSession() {
    const name = prompt("Name this session:", "yelp-" + state.leads.length + "-leads");
    if (!name) return;
    const s = (await chrome.storage.local.get(["yle_sessions"])).yle_sessions || {};
    s[name] = state.leads;
    await chrome.storage.local.set({ yle_sessions: s });
    status(`Saved session "${name}" (${state.leads.length} leads).`);
  }
  async function loadSession() {
    const s = (await chrome.storage.local.get(["yle_sessions"])).yle_sessions || {};
    const names = Object.keys(s);
    if (!names.length) { status("No saved sessions."); return; }
    const pick = prompt("Load which session?\n\n" + names.join("\n"), names[names.length - 1]);
    if (!pick || !s[pick]) return;
    state.leads = s[pick]; state.seen = new Set(state.leads.map((l) => l.url));
    await saveState(); refreshAll();
    status(`Loaded "${pick}" (${state.leads.length} leads).`);
  }

  // ---------- export ----------
  function toCsv(rows, headers) {
    const esc = (v) => `"${String(v == null ? "" : v).replace(/"/g, '""')}"`;
    const lines = [headers.join(",")];
    for (const r of rows) lines.push(headers.map((h) => esc(r[h])).join(","));
    return lines.join("\n");
  }
  function download(filename, text) {
    const blob = new Blob([text], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = filename; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  const FULL_COLS = ["name", "phone", "address", "website", "email", "socials",
    "rating", "reviewCount", "categories", "priceRange", "latitude", "longitude", "LeadScore", "QualityTier"];
  function exportFull()  { if (guard()) download("yelp-leads.csv", toCsv(state.leads, FULL_COLS)); }
  function exportPhone() { if (guard()) download("yelp-phones.csv", toCsv(state.leads.filter(l => l.phone), ["name", "phone", "address"])); }
  function exportWeb()   { if (guard()) download("yelp-websites.csv", toCsv(state.leads.filter(l => l.website), ["name", "website", "email"])); }
  function exportMissing(){ if (guard()) download("yelp-missing.csv", toCsv(state.leads.filter(l => !l.phone || !l.email || !l.website), FULL_COLS)); }
  function guard() { if (!state.leads.length) { status("Nothing to export yet."); return false; } return true; }

  // ---------- preview modal ----------
  function openPreview() {
    closeModal();
    const total = state.leads.length;
    const wp = state.leads.filter(l => l.phone).length;
    const we = state.leads.filter(l => l.email).length;
    const ws = state.leads.filter(l => l.website).length;
    const rows = state.leads.slice().reverse().map((l) => `<tr>
      <td>${escapeHtml(l.name)}</td><td>${escapeHtml(l.phone)}</td>
      <td>${escapeHtml(l.email)}</td><td>${escapeHtml(l.website)}</td>
      <td>${escapeHtml(l.rating)}</td><td>${l.LeadScore} <span class="${l.LeadScore>=70?'mle-good':l.LeadScore<30?'mle-bad':''}">${l.QualityTier}</span></td>
    </tr>`).join("");
    const back = document.createElement("div");
    back.className = "mle-modal-backdrop"; back.id = "yle-modal";
    back.innerHTML = `<div class="mle-modal">
      <div class="mle-modal-head"><b>Lead Preview</b><button class="mle-btn" id="yle-modal-close" style="background:rgba(255,255,255,.18);color:#fff">Close</button></div>
      <div class="mle-modal-body">
        <div class="mle-stat-line">
          <span class="mle-stat-pill">Total: ${total}</span>
          <span class="mle-stat-pill">With Phone: ${wp}</span>
          <span class="mle-stat-pill">With Email: ${we}</span>
          <span class="mle-stat-pill">With Website: ${ws}</span>
        </div>
        <table style="width:100%;border-collapse:collapse;font-size:12px">
          <thead><tr style="text-align:left;color:#475569">
            <th>Name</th><th>Phone</th><th>Email</th><th>Website</th><th>Rating</th><th>Score</th></tr></thead>
          <tbody>${rows || '<tr><td colspan="6" style="padding:14px;color:#64748b">No leads yet.</td></tr>'}</tbody>
        </table>
      </div></div>`;
    document.body.appendChild(back);
    back.addEventListener("click", (e) => { if (e.target === back) closeModal(); });
    $("#yle-modal-close").addEventListener("click", closeModal);
  }
  function closeModal() { const m = $("#yle-modal"); if (m) m.remove(); }

  // ---------- live feed + metrics ----------
  function refreshAll() {
    const total = state.leads.length;
    const wp = state.leads.filter(l => l.phone).length;
    const we = state.leads.filter(l => l.email).length;
    setText("#yle-m-total", total); setText("#yle-m-phone", wp); setText("#yle-m-email", we);
    setText("#yle-count", total); setText("#yle-live-note", `${total} captured`);
    const list = $("#yle-live-list"); if (!list) return;
    const recent = state.leads.slice(-50).reverse();
    if (!recent.length) { list.innerHTML = '<div class="mle-live-empty">No leads yet — pick a mode and hit Start.</div>'; return; }
    list.innerHTML = recent.map((l) => {
      const pills = [];
      if (l.phone) pills.push('<span class="mle-live-pill">📞</span>');
      if (l.email) pills.push('<span class="mle-live-pill" style="background:#dcfce7;color:#065f46">✉</span>');
      if (l.website) pills.push('<span class="mle-live-pill" style="background:#dbeafe;color:#174ea6">site</span>');
      if (l.socials) pills.push('<span class="mle-live-pill" style="background:#ffe4f0;color:#9d174d">social</span>');
      const sc = `<span class="mle-live-pill" style="background:#f1f5f9;color:#334155">${l.LeadScore}</span>`;
      return `<div class="mle-live-row">
        <b>${escapeHtml(l.name)}</b> ${l.rating ? `<span style="color:#d32323;font-weight:900">★${escapeHtml(l.rating)}</span>` : ""}
        <div class="mle-live-meta">${pills.join("")}${sc}
          ${l.phone ? `<span>${escapeHtml(l.phone)}</span>` : ""}</div>
      </div>`;
    }).join("");
  }
  function setText(sel, v) { const el = $(sel); if (el) el.textContent = v; }
  function setRunning(running) {
    const p = $("#yle-panel"); if (p) p.classList.toggle("yle-live-on", running);
    const b = $("#yle-start"); if (b) b.textContent = running ? "Running…" : "Start — Save Leads + Phones";
    const auto = $("#yle-autoscroll");
    if (auto) { auto.textContent = `Auto Scroll: ${state.autoScroll ? "ON" : "OFF"}`; auto.classList.toggle("off", !state.autoScroll); }
  }

  // ---------- styles (lifted from the Command Center design system) ----------
  const STYLE = `
  #yle-panel{position:fixed;top:16px;right:16px;z-index:2147483647;width:330px;
    max-height:calc(100vh - 32px);overflow-y:auto;
    font:13px/1.4 Inter,system-ui,Arial,sans-serif;color:#0f172a;
    background:#fff;border:1px solid #ffd5d5;border-radius:20px;padding:11px;
    border-top:4px solid #d32323;
    box-shadow:0 16px 44px rgba(175,6,6,.28),0 4px 12px rgba(0,0,0,.18)}
  #yle-panel::-webkit-scrollbar{width:9px}
  #yle-panel::-webkit-scrollbar-thumb{background:#f0b4b4;border-radius:8px}
  #yle-launcher{position:fixed;bottom:20px;right:20px;z-index:2147483647;width:52px;height:52px;
    border:0;border-radius:50%;cursor:pointer;background:linear-gradient(135deg,#f43f3f,#d32323);
    box-shadow:0 8px 22px rgba(211,35,35,.5);display:flex;align-items:center;justify-content:center}
  #yle-launcher:hover{filter:brightness(1.07)}
  #yle-launcher svg{display:block}
  #yle-panel *{box-sizing:border-box}
  .mle-command-top{display:flex;gap:8px;align-items:center;justify-content:space-between;margin-bottom:8px;cursor:move;user-select:none}
  .yle-logo{display:inline-flex;align-items:center;justify-content:center;width:28px;height:28px;border-radius:9px;
    background:linear-gradient(135deg,#f43f3f,#d32323);box-shadow:0 4px 10px rgba(211,35,35,.4)}
  .yle-logo svg{display:block}
  .mle-command-title{font-size:12px;font-weight:900;color:#d32323;text-transform:uppercase;letter-spacing:.08em}
  .mle-command-pill{font-size:10px;font-weight:900;color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;border-radius:999px;padding:4px 7px}
  .yle-x{margin-left:auto;border:0;background:#f1f5f9;color:#475569;width:24px;height:24px;border-radius:8px;cursor:pointer;font-weight:900}
  #yle-count{font-size:10px;font-weight:900;color:#fff;background:#d32323;border-radius:999px;padding:4px 8px}
  .mle-simple-sub{font-size:12px;line-height:1.35;color:#475569;margin:0 0 10px}
  .mle-mini-metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:10px}
  .mle-mini-card{background:linear-gradient(180deg,#fff,#f8fafc);border:1px solid #e2e8f0;border-radius:14px;padding:8px;text-align:center}
  .mle-mini-card b{font-size:18px;color:#0f172a;display:block}
  .mle-mini-card span{font-size:10px;color:#64748b;font-weight:800;text-transform:uppercase;letter-spacing:.05em}
  .mle-simple-select{width:100%;border:1px solid #cbd5e1;border-radius:14px;padding:11px;background:#fff;color:#0f172a;font-weight:900;font-size:13px;margin-bottom:9px}
  .mle-simple-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
  .mle-btn{border:0;border-radius:15px;padding:11px 8px;font-size:13px;font-weight:900;cursor:pointer;
    box-shadow:0 10px 22px rgba(15,23,42,.10);transition:filter .15s,transform .06s}
  .mle-btn:hover{filter:brightness(1.05)} .mle-btn:active{transform:translateY(1px)}
  .mle-span2{grid-column:span 2}
  .mle-run{background:linear-gradient(135deg,#f43f3f,#d32323);color:#fff}
  .mle-stop{background:#fee2e2;color:#991b1b}
  .mle-export{background:#dcfce7;color:#065f46}
  .mle-blue{background:#dbeafe;color:#174ea6}
  .mle-orange{background:#ffedd5;color:#9a3412}
  .mle-slate{background:#e2e8f0;color:#334155}
  .mle-autoscroll{width:100%;margin-top:9px;background:#dcfce7;color:#065f46}
  .mle-autoscroll.off{background:#fee2e2;color:#991b1b}
  .mle-live-leads{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:10px;margin:10px 0;box-shadow:0 8px 20px rgba(15,23,42,.06)}
  .mle-live-head{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:12px;font-weight:900;color:#0f172a;margin-bottom:8px}
  .mle-live-note{font-size:10px;color:#64748b;font-weight:800}
  .mle-live-list{display:flex;flex-direction:column;gap:6px;max-height:170px;overflow:auto;padding-right:2px}
  .mle-live-row{border:1px solid #e5e7eb;background:#f8fafc;border-radius:12px;padding:7px 8px;font-size:11px;line-height:1.3}
  .mle-live-meta{display:flex;gap:6px;flex-wrap:wrap;color:#334155;margin-top:4px;align-items:center}
  .mle-live-pill{background:#e0f2fe;color:#075985;border-radius:999px;padding:2px 7px;font-weight:900}
  .mle-live-empty{color:#64748b;font-size:12px;text-align:center;padding:14px 4px}
  .mle-statusbar{display:flex;align-items:center;gap:8px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:13px;padding:9px;font-size:11px;color:#475569}
  #yle-dot{width:8px;height:8px;border-radius:50%;background:#cbd5e1;flex:0 0 auto}
  #yle-panel.yle-live-on #yle-dot{background:#16a34a;animation:yle-pulse 1.1s infinite}
  @keyframes yle-pulse{0%{box-shadow:0 0 0 0 rgba(34,197,94,.55)}70%{box-shadow:0 0 0 7px rgba(34,197,94,0)}100%{box-shadow:0 0 0 0 rgba(34,197,94,0)}}
  .mle-details-toggle{width:100%;margin-top:10px;background:#e2e8f0;color:#334155;border:0;border-radius:14px;padding:10px;font-weight:900;cursor:pointer}
  .mle-details-box{display:none;margin-top:10px}
  .mle-details-box.open{display:block}
  .mle-section-label{font-size:11px;font-weight:900;color:#334155;text-transform:uppercase;letter-spacing:.08em;margin:10px 0 7px}
  .mle-modal-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:2147483647;display:flex;align-items:center;justify-content:center;font:13px Inter,system-ui,Arial}
  .mle-modal{width:min(900px,92vw);max-height:86vh;overflow:auto;background:#fff;border-radius:18px;box-shadow:0 26px 100px rgba(0,0,0,.35);border:1px solid #cbd5e1;color:#0f172a}
  .mle-modal-head{position:sticky;top:0;background:linear-gradient(135deg,#f43f3f,#d32323);color:#fff;padding:14px 16px;display:flex;justify-content:space-between;align-items:center}
  .mle-modal-body{padding:14px}
  .mle-modal table th,.mle-modal table td{padding:6px 8px;border-bottom:1px solid #eef2f7;vertical-align:top}
  .mle-stat-line{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px}
  .mle-stat-pill{background:#f1f5f9;border:1px solid #e2e8f0;border-radius:999px;padding:6px 9px;font-size:12px;font-weight:800}
  .mle-good{color:#047857;font-weight:900} .mle-bad{color:#b91c1c;font-weight:900}
  .mle-live-list::-webkit-scrollbar{width:8px}.mle-live-list::-webkit-scrollbar-thumb{background:#dbe0ea;border-radius:8px}
  `;

  function togglePanel() {
    const p = document.getElementById("yle-panel");
    if (p) p.style.display = (p.style.display === "none") ? "" : "none";
  }

  // ---------- build the panel ----------
  function buildPanel() {
    if (document.getElementById("yle-panel")) return;   // already present
    if (!document.getElementById("yle-style")) {
      const style = document.createElement("style"); style.id = "yle-style"; style.textContent = STYLE;
      (document.head || document.documentElement).appendChild(style);
    }
    const panel = document.createElement("div"); panel.id = "yle-panel";
    panel.innerHTML = `
      <div class="mle-command-top" id="yle-handle">
        <span class="yle-logo"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><g stroke="#fff" stroke-width="2.5" stroke-linecap="round" fill="none"><line x1="12" y1="15" x2="7.5" y2="6.5"/><line x1="12" y1="15" x2="12" y2="4.3"/><line x1="12" y1="15" x2="16.8" y2="6.8"/><line x1="12" y1="15" x2="18.4" y2="11.4"/><line x1="12" y1="15" x2="6" y2="11.8"/></g></svg></span>
        <span class="mle-command-title">Yelp Leads</span>
        <span class="mle-command-pill">${VERSION}</span>
        <span id="yle-count">0</span>
        <button class="yle-x" id="yle-hide" title="Hide panel">✕</button>
      </div>
      <div class="mle-simple-sub">Scrape Yelp results → phone, email, website, rating &amp; geo.</div>

      <div class="mle-mini-metrics">
        <div class="mle-mini-card"><b id="yle-m-total">0</b><span>Leads</span></div>
        <div class="mle-mini-card"><b id="yle-m-phone">0</b><span>Phone</span></div>
        <div class="mle-mini-card"><b id="yle-m-email">0</b><span>Email</span></div>
      </div>

      <select class="mle-simple-select" id="yle-mode">
        <option value="all">All-In-One Full Data</option>
        <option value="phones">Get Phone + Website Details</option>
        <option value="social">Find Social Media + Email</option>
        <option value="fast">Fast Volume Scrape</option>
        <option value="manual">Manual Extract (this page)</option>
      </select>

      <div class="mle-simple-grid">
        <button class="mle-btn mle-run mle-span2" id="yle-start">Start — Save Leads + Phones</button>
        <button class="mle-btn mle-stop" id="yle-stop">Stop</button>
        <button class="mle-btn mle-export" id="yle-export">Export</button>
      </div>
      <button class="mle-btn mle-autoscroll" id="yle-autoscroll">Auto Scroll: ON</button>

      <div class="mle-live-leads">
        <div class="mle-live-head"><span>Live Leads</span><span class="mle-live-note" id="yle-live-note">0 captured</span></div>
        <div class="mle-live-list" id="yle-live-list"></div>
      </div>

      <div class="mle-statusbar"><span id="yle-dot"></span><span id="yle-status">Ready.</span></div>

      <button class="mle-details-toggle" id="yle-adv-toggle">Advanced Tools</button>
      <div class="mle-details-box" id="yle-adv-box">
        <div class="mle-section-label">Data Tools</div>
        <div class="mle-simple-grid">
          <button class="mle-btn mle-run mle-span2" id="yle-test">🔍 Test 1 Business</button>
          <button class="mle-btn mle-blue" id="yle-preview">Preview Leads</button>
          <button class="mle-btn mle-slate" id="yle-dedupe">Clean Duplicates</button>
          <button class="mle-btn mle-slate" id="yle-missing">Check Missing</button>
          <button class="mle-btn mle-orange" id="yle-weak">Delete Weak</button>
        </div>
        <div class="mle-section-label">Export Sheets</div>
        <div class="mle-simple-grid">
          <button class="mle-btn mle-export" id="yle-exp-phone">Phone-Only Sheet</button>
          <button class="mle-btn mle-export" id="yle-exp-web">Website-Only Sheet</button>
          <button class="mle-btn mle-export mle-span2" id="yle-exp-missing">Missing-Data Sheet</button>
        </div>
        <div class="mle-section-label">Sessions</div>
        <div class="mle-simple-grid">
          <button class="mle-btn mle-blue" id="yle-save">Save Session</button>
          <button class="mle-btn mle-blue" id="yle-load">Load Session</button>
          <button class="mle-btn mle-stop mle-span2" id="yle-clear">Clear Leads</button>
        </div>
      </div>`;
    // Anchor to <html>, not <body> — Yelp's single-page app re-renders <body>
    // and would wipe the panel out.
    document.documentElement.appendChild(panel);

    // Always-visible launcher to summon/hide the panel (so the ✕ never loses it).
    const burst = '<svg viewBox="0 0 24 24" width="22" height="22"><g stroke="#fff" stroke-width="2.5" stroke-linecap="round" fill="none"><line x1="12" y1="15" x2="7.5" y2="6.5"/><line x1="12" y1="15" x2="12" y2="4.3"/><line x1="12" y1="15" x2="16.8" y2="6.8"/><line x1="12" y1="15" x2="18.4" y2="11.4"/><line x1="12" y1="15" x2="6" y2="11.8"/></g></svg>';
    const launcher = document.createElement("button");
    launcher.id = "yle-launcher"; launcher.title = "Yelp Lead Extractor"; launcher.innerHTML = burst;
    launcher.onclick = togglePanel;
    document.documentElement.appendChild(launcher);

    // wire controls
    $("#yle-start").onclick = start;
    $("#yle-stop").onclick = stop;
    $("#yle-export").onclick = exportFull;
    $("#yle-mode").onchange = (e) => { applyMode(e.target.value); saveState(); setRunning(state.running); };
    $("#yle-autoscroll").onclick = () => { state.autoScroll = !state.autoScroll; saveState(); setRunning(state.running); };
    $("#yle-hide").onclick = () => { panel.style.display = "none"; };
    $("#yle-adv-toggle").onclick = () => $("#yle-adv-box").classList.toggle("open");
    $("#yle-test").onclick = testFirst;
    $("#yle-preview").onclick = openPreview;
    $("#yle-dedupe").onclick = cleanDuplicates;
    $("#yle-missing").onclick = checkMissing;
    $("#yle-weak").onclick = deleteWeak;
    $("#yle-exp-phone").onclick = exportPhone;
    $("#yle-exp-web").onclick = exportWeb;
    $("#yle-exp-missing").onclick = exportMissing;
    $("#yle-save").onclick = saveSession;
    $("#yle-load").onclick = loadSession;
    $("#yle-clear").onclick = clearLeads;

    makeDraggable(panel, $("#yle-handle"));
    applyUi();
  }

  // drag + position persistence
  function makeDraggable(panel, handle) {
    let drag = false, sx = 0, sy = 0, sl = 0, st = 0;
    handle.addEventListener("mousedown", (e) => {
      if (e.target.closest("#yle-hide")) return;
      const r = panel.getBoundingClientRect();
      panel.style.left = r.left + "px"; panel.style.top = r.top + "px"; panel.style.right = "auto";
      drag = true; sx = e.clientX; sy = e.clientY; sl = r.left; st = r.top; e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!drag) return;
      let nl = Math.max(0, Math.min(window.innerWidth - 80, sl + e.clientX - sx));
      let nt = Math.max(0, Math.min(window.innerHeight - 30, st + e.clientY - sy));
      panel.style.left = nl + "px"; panel.style.top = nt + "px";
    });
    window.addEventListener("mouseup", () => { if (drag) { drag = false; saveUi(); } });
  }
  function saveUi() {
    const p = $("#yle-panel"); if (!p) return;
    chrome.storage.local.set({ yle_ui: { left: p.style.left || "", top: p.style.top || "" } });
  }
  async function applyUi() {
    const { yle_ui } = await chrome.storage.local.get(["yle_ui"]);
    const p = $("#yle-panel");
    if (p && yle_ui && yle_ui.left) { p.style.left = yle_ui.left; p.style.top = yle_ui.top; p.style.right = "auto"; }
  }

  // ---------- init ----------
  // Toolbar-icon toggle (registered once, survives panel rebuilds).
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && msg.action === "togglePanel") { buildPanel(); togglePanel(); }
  });

  (async function init() {
    buildPanel();
    await loadState();
    if ($("#yle-mode")) $("#yle-mode").value = state.mode;
    refreshAll(); setRunning(state.running);

    // Watchdog: if Yelp's app ever removes our panel, rebuild it.
    setInterval(() => {
      if (!document.getElementById("yle-panel")) {
        buildPanel();
        if ($("#yle-mode")) $("#yle-mode").value = state.mode;
        refreshAll(); setRunning(state.running);
      }
    }, 1500);

    if (state.running && (state.mode === "all" || state.mode === "fast")) {
      const p = $("#yle-panel"); if (p) p.style.display = "";   // show progress while a run resumes
      status("Resuming…");
      await sleep(rand(1500, 3000));
      processCurrentPage();
    }
  })();
})();
