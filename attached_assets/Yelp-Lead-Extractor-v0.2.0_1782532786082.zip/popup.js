// Wires the "collect email" checkbox to storage so the content script can read it.
const box = document.getElementById("collectEmail");

chrome.storage.sync.get(["collectEmail"], (cfg) => {
  box.checked = cfg.collectEmail !== false;
});

box.addEventListener("change", () => {
  chrome.storage.sync.set({ collectEmail: box.checked });
});
