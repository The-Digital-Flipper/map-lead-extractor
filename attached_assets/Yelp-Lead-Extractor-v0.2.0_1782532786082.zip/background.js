// Background service worker.
// 1) Clicking the toolbar icon toggles the in-page panel (no popup).
// 2) Fetches a business's OWN website (a cross-origin request the content
//    script can't make) and returns the HTML for email/social extraction.

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab || !tab.id) return;
  try {
    // If the content script is already on the page, just toggle the panel.
    await chrome.tabs.sendMessage(tab.id, { action: "togglePanel" });
  } catch (e) {
    // Not injected yet (tab opened before the extension loaded) — inject it now;
    // the panel shows itself on load.
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["contentScript.js"] });
    } catch (e2) {
      // Not an injectable page (e.g. chrome:// or non-Yelp). Nothing to do.
    }
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.action === "fetchUrl") {
    fetch(msg.url, { redirect: "follow" })
      .then((r) => r.text())
      .then((text) => sendResponse({ ok: true, text }))
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true; // async reply
  }
});
