import { Commands, ROUTE_TO_CONTENT } from "./src/messages.js";

const CONNECT_URL = "https://mapleadextractor.net/connect-extension";

const status       = document.getElementById("status");
const openPanel    = document.getElementById("openPanel");
const openMaps     = document.getElementById("openMaps");
const signinSection    = document.getElementById("signin-section");
const connectedSection = document.getElementById("connected-section");
const googleSignIn     = document.getElementById("googleSignIn");
const connectedEmail   = document.getElementById("connected-email");
const disconnectBtn    = document.getElementById("disconnect");

async function sendToContent(command, payload = {}) {
  return chrome.runtime.sendMessage({
    type: ROUTE_TO_CONTENT,
    payload: { command, ...payload }
  });
}

// ── Show the right section based on whether the user is connected ─────────────
async function refreshConnectionUI() {
  const { mleApiKey, mleEmail } = await chrome.storage.local.get(["mleApiKey", "mleEmail"]);
  if (mleApiKey) {
    signinSection.hidden = true;
    connectedSection.hidden = false;
    connectedEmail.textContent = mleEmail || "Connected";
  } else {
    signinSection.hidden = false;
    connectedSection.hidden = true;
  }
}

// ── Google Sign-In: opens the connect page in a new tab ───────────────────────
googleSignIn.addEventListener("click", async () => {
  await chrome.tabs.create({ url: CONNECT_URL });
  window.close();
});

// ── Disconnect ─────────────────────────────────────────────────────────────────
disconnectBtn.addEventListener("click", async () => {
  await chrome.storage.local.remove(["mleApiKey", "mleEmail"]);
  await refreshConnectionUI();
});

// ── Open Extractor ─────────────────────────────────────────────────────────────
openPanel.addEventListener("click", async () => {
  status.textContent = "Opening extractor...";
  const response = await sendToContent(Commands.SHOW_PANEL);
  if (response?.ok) {
    status.textContent = "Extractor opened on Google Maps.";
    window.close();
    return;
  }
  status.textContent = response?.error || "Could not open extractor.";
});

// ── Open Google Maps ───────────────────────────────────────────────────────────
openMaps.addEventListener("click", async () => {
  await chrome.tabs.create({ url: "https://www.google.com/maps/search/restaurants+in+Manhattan+New+York" });
  window.close();
});

// Refresh when the connect tab pushes a key back (user just signed in)
chrome.storage.onChanged.addListener((changes) => {
  if (changes.mleApiKey) refreshConnectionUI();
});

refreshConnectionUI();
