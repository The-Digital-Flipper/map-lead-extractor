// Background service worker.
// 1) Clicking the toolbar icon opens the popup (default_popup in manifest).
// 2) Fetches a business's OWN website cross-origin and returns HTML for
//    email/social extraction.
// 3) Handles MLE_CONNECT/DISCONNECT/GET_STATUS messages from mapleadextractor.net.

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.action === "fetchUrl") {
    fetch(msg.url, { redirect: "follow" })
      .then((r) => r.text())
      .then((text) => sendResponse({ ok: true, text }))
      .catch((e) => sendResponse({ ok: false, error: String(e) }));
    return true; // async reply
  }
});

// ── Messages from mapleadextractor.net (the connect page) ─────────────────────
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === "MLE_CONNECT") {
    const { apiKey, email } = msg;
    if (!apiKey) { sendResponse({ ok: false, error: "No apiKey provided" }); return; }
    chrome.storage.local.set({ mleApiKey: apiKey, mleEmail: email || "" }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === "MLE_DISCONNECT") {
    chrome.storage.local.remove(["mleApiKey", "mleEmail"], () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === "GET_STATUS") {
    chrome.storage.local.get(["mleApiKey", "mleEmail"], (data) => {
      sendResponse({ connected: !!data.mleApiKey, email: data.mleEmail || null });
    });
    return true;
  }
});

// ── Save leads to the backend ──────────────────────────────────────────────────
async function saveLeadsToBackend(leads) {
  const { mleApiKey } = await chrome.storage.local.get("mleApiKey");
  if (!mleApiKey || !leads || !leads.length) return;
  try {
    await fetch("https://mapleadextractor.net/api/leads/save", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Api-Key": mleApiKey
      },
      body: JSON.stringify({ leads, source: "yelp" })
    });
  } catch (e) {
    console.warn("[MLE] backend sync failed:", e);
  }
}

// Listen for content script's request to sync leads
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.action === "syncLeads") {
    saveLeadsToBackend(msg.leads).then(() => sendResponse({ ok: true })).catch(() => sendResponse({ ok: false }));
    return true;
  }
});
