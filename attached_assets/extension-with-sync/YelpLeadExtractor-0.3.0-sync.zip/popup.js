const CONNECT_URL = "https://mapleadextractor.net/connect-extension";

const signinSection    = document.getElementById("signin-section");
const connectedSection = document.getElementById("connected-section");
const googleSignIn     = document.getElementById("googleSignIn");
const connectedEmail   = document.getElementById("connected-email");
const disconnectBtn    = document.getElementById("disconnect");
const box              = document.getElementById("collectEmail");

// ── Connection status ──────────────────────────────────────────────────────────
async function refreshConnectionUI() {
  const { mleApiKey, mleEmail } = await chrome.storage.local.get(["mleApiKey", "mleEmail"]);
  if (mleApiKey) {
    signinSection.hidden = true;
    connectedSection.hidden = false;
    connectedEmail.textContent = mleEmail || "Connected";
  } else {
    signinSection.hidden = false;
    connectedSection.hidden = true;
  }
}

// ── Sign in → open connect page ────────────────────────────────────────────────
googleSignIn.addEventListener("click", async () => {
  await chrome.tabs.create({ url: CONNECT_URL });
  window.close();
});

// ── Disconnect ─────────────────────────────────────────────────────────────────
disconnectBtn.addEventListener("click", async () => {
  await chrome.storage.local.remove(["mleApiKey", "mleEmail"]);
  await refreshConnectionUI();
});

// ── Collect-email checkbox (original feature) ──────────────────────────────────
chrome.storage.sync.get(["collectEmail"], (cfg) => {
  box.checked = cfg.collectEmail !== false;
});
box.addEventListener("change", () => {
  chrome.storage.sync.set({ collectEmail: box.checked });
});

// Update UI when the connect tab pushes a key back
chrome.storage.onChanged.addListener((changes) => {
  if (changes.mleApiKey) refreshConnectionUI();
});

refreshConnectionUI();
