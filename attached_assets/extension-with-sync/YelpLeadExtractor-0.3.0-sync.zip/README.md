# Yelp Lead Scraper (Lite)

A stripped-down, readable Chrome extension that scrapes a Yelp search into a CSV of
**name, phone, address, website, email, socials, rating, reviewCount, categories,
priceRange, latitude, longitude** (12 columns). Built as a learning skeleton — the
same "inject a button → read structured data off the page → enrich via the website →
export" pattern works for Google Maps, Bing, or marketplace scrapers too.

The UI is a floating panel (top-right) that is **draggable**, **collapsible**, and shows
a **live feed** of leads as they're collected. Its position survives page turns.

## How to load it (developer mode)

1. Open Chrome → `chrome://extensions`
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked** and select this `yelp-lead-scraper` folder.
4. Pin the extension if you like.

## How to use it

1. Go to a Yelp search, e.g.
   `https://www.yelp.com/search?find_desc=plumbers&find_loc=Pensacola, FL`
2. A panel appears in the top-right. Drag it anywhere; click **▾** to collapse it.
   Click **Start**.
3. It visits each business, pulls contact info, optionally grabs email/socials from
   the business website, then auto-advances to the next page.
4. Click **Export CSV** anytime. **Clear** resets the collected list.

The checkbox in the extension popup toggles whether it also fetches emails/socials.

## How it works (the 5 pieces)

| File | Job |
|------|-----|
| `manifest.json` | Permissions + tells Chrome to run `contentScript.js` on Yelp search pages |
| `contentScript.js` | The brain: toolbar UI, reading Yelp's embedded JSON, paging, CSV export |
| `background.js` | Fetches each business's *own website* (cross-origin) for email enrichment |
| `popup.html` / `popup.js` | Settings toggle |

The key trick is in `extractContact()`: Yelp ships each page's data as a big JSON
"Apollo state" blob in a `<script>` tag. We read fields out of that blob instead of
scraping rendered HTML — far more reliable. Emails come from `extractEmails()`, which
also decodes Cloudflare-obfuscated addresses.

## The honest caveats

- **It will break when Yelp changes their page structure.** The Apollo-state reading
  is the fragile part — expect to patch `extractContact()` periodically.
- **Go slow.** Random delays are built in on purpose. Hammering Yelp gets you
  rate-limited or captcha'd.
- **Terms of Service / law.** Scraping Yelp violates their ToS, and how you *use*
  harvested emails is regulated (CAN-SPAM / GDPR). Keep it to public business contact
  info and personal/educational use.

## Ideas to extend

- Capture rating, review count, categories, lat/long (already in the Apollo state).
- Follow `/contact` and `/about` pages of each website for better email hit-rate.
- Swap `collectBusinessLinks()` + `extractContact()` to point the same engine at a
  different site.
